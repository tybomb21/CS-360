package com.zybooks.morgan_tyler_project3;
import androidx.appcompat.app.AppCompatActivity;

import com.zybooks.morgan_tyler_project2.R;

import android.content.ContentValues;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.provider.BaseColumns;

public class MainActivity extends AppCompatActivity {

    private Button createAccountButton;
    private Button loginButton;
    private EditText usernameEditText;
    private EditText passwordEditText;
    private LoginDatabaseHelper dbHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createAccountButton = findViewById(R.id.create_account_button);
        loginButton = findViewById(R.id.login_button);
        usernameEditText = findViewById(R.id.username_edit_text);
        passwordEditText = findViewById(R.id.password_edit_text);
        dbHelper = new LoginDatabaseHelper(this);

        createAccountButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = usernameEditText.getText().toString();
                String password = passwordEditText.getText().toString();

                SQLiteDatabase db = dbHelper.getWritableDatabase();

                ContentValues values = new ContentValues();
                values.put("username", username);
                values.put("password", password);

                long newRowId = db.insert("login", null, values);

                if (newRowId != -1) {
                    Toast.makeText(MainActivity.this, "Account created!", Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(MainActivity.this, "Error creating account", Toast.LENGTH_SHORT).show();
                }
            }
        });

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Check if user is logged in
                boolean isLoggedIn = checkLoggedIn();

                // Open the appropriate activity based on login status
                if (isLoggedIn) {
                    Intent intent = new Intent(MainActivity.this, CalendarActivity.class);
                    startActivity(intent);
                } else {
                    // Open login activity
                    Intent intent = new Intent(MainActivity.this, LoginActivity.class);
                    startActivity(intent);
                }
            }
        });
    }

    private boolean checkLoggedIn() {
        SQLiteDatabase db = dbHelper.getReadableDatabase();

        String[] projection = {
                BaseColumns._ID,
                "username",
                "password"
        };

        String selection = "username = ? AND password = ?";
        String[] selectionArgs = {
                usernameEditText.getText().toString(),
                passwordEditText.getText().toString()
        };

        Cursor cursor = db.query(
                "login",
                projection,
                selection,
                selectionArgs,
                null,
                null,
                null
        );

        boolean isLoggedIn = false;

        if (cursor.getCount() == 1) {
            isLoggedIn = true;
        }

        cursor.close();
        db.close();

        return isLoggedIn;
    }

    @Override
    protected void onDestroy() {
        dbHelper.close();
        super.onDestroy();
    }
}
