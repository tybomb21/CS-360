package com.zybooks.morgan_tyler_project3;
import java.util.Calendar;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.widget.CalendarView;
import android.widget.EditText;
import android.text.InputType;
import android.app.AlertDialog;

import com.zybooks.morgan_tyler_project2.R;

import java.text.SimpleDateFormat;
import java.util.Locale;




public class CalendarActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_calendar);

        CalendarView mCalendarView = findViewById(R.id.calendar_view);
        mCalendarView.setOnDateChangeListener(new CalendarView.OnDateChangeListener() {

            public void onSelectedDayChange(@NonNull CalendarView calendarView, int year, int month, int dayOfMonth) {
                // Display input box DialogFragment
                InputBoxDialogFragment dialogFragment = InputBoxDialogFragment.newInstance(year, month, dayOfMonth);
                dialogFragment.show(getSupportFragmentManager(), "input_box_dialog");

                final Calendar selectedCalendar = Calendar.getInstance();
                selectedCalendar.set(year, month, dayOfMonth);

                final EditText weightEditText = new EditText(CalendarActivity.this);
                weightEditText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);
                weightEditText.setHint("Weight");

                SimpleDateFormat dateFormat = new SimpleDateFormat("MM/dd/yyyy", Locale.US);


                new AlertDialog.Builder(CalendarActivity.this)
                        .setTitle("Enter weight for " + dateFormat.format(selectedCalendar.getTime()) + ":");

            }
        });


    }
}
