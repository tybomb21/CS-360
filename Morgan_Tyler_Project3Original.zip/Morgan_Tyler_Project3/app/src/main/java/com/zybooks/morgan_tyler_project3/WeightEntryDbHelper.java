package com.zybooks.morgan_tyler_project3;

import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.Context;
import java.util.Date;
import java.util.ArrayList;
import java.util.List;


public class WeightEntryDbHelper extends SQLiteOpenHelper {
    public static final int DATABASE_VERSION = 1;
    public static final String DATABASE_NAME = "WeightEntries.db";

    private static final String SQL_CREATE_ENTRIES =
            "CREATE TABLE " + WeightEntryContract.WeightEntry.TABLE_NAME + " (" +
                    WeightEntryContract.WeightEntry._ID + " INTEGER PRIMARY KEY," +
                    WeightEntryContract.WeightEntry.COLUMN_NAME_DATE + " INTEGER," +
                    WeightEntryContract.WeightEntry.COLUMN_NAME_WEIGHT + " REAL)";

    private static final String SQL_DELETE_ENTRIES =
            "DROP TABLE IF EXISTS " + WeightEntryContract.WeightEntry.TABLE_NAME;

    public WeightEntryDbHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    public void onCreate(SQLiteDatabase db) {
        db.execSQL(SQL_CREATE_ENTRIES);
    }

    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL(SQL_DELETE_ENTRIES);
        onCreate(db);
    }

    public void onDowngrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        onUpgrade(db, oldVersion, newVersion);
    }

    public void addWeightEntry(Date date, double weight) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(WeightEntryContract.WeightEntry.COLUMN_NAME_DATE, date.getTime());
        values.put(WeightEntryContract.WeightEntry.COLUMN_NAME_WEIGHT, weight);

        db.insert(WeightEntryContract.WeightEntry.TABLE_NAME, null, values);
    }

    public List<WeightEntryContract.WeightEntry> getWeightEntries() {
        List<WeightEntryContract.WeightEntry> weightEntries = new ArrayList<>();

        SQLiteDatabase db = this.getReadableDatabase();

        String[] projection = {
                WeightEntryContract.WeightEntry._ID,
                WeightEntryContract.WeightEntry.COLUMN_NAME_DATE,
                WeightEntryContract.WeightEntry.COLUMN_NAME_WEIGHT
        };

        Cursor cursor = db.query(
                WeightEntryContract.WeightEntry.TABLE_NAME,
                projection,
                null,
                null,
                null,
                null,
                null
        );

        while (cursor.moveToNext()) {
            long dateMillis = cursor.getLong(cursor.getColumnIndexOrThrow(WeightEntryContract.WeightEntry.COLUMN_NAME_DATE));
            double weight = cursor.getDouble(cursor.getColumnIndexOrThrow(WeightEntryContract.WeightEntry.COLUMN_NAME_WEIGHT));
            weightEntries.add(new WeightEntryContract.WeightEntry(dateMillis, weight));


        }

        cursor.close();

        return weightEntries;
    }
}
