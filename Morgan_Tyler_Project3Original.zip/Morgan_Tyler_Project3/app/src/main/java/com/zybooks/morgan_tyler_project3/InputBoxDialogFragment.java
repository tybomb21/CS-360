package com.zybooks.morgan_tyler_project3;
import com.zybooks.morgan_tyler_project2.R;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.text.InputType;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

import androidx.fragment.app.DialogFragment;

public class InputBoxDialogFragment extends DialogFragment {

    private OnWeightEnteredListener mWeightEnteredListener;

    public interface OnWeightEnteredListener {
        void onWeightEntered(double weight, int year, int month, int dayOfMonth);
    }

    public static InputBoxDialogFragment newInstance(int year, int month, int dayOfMonth) {
        InputBoxDialogFragment fragment = new InputBoxDialogFragment();
        Bundle args = new Bundle();
        args.putInt("year", year);
        args.putInt("month", month);
        args.putInt("dayOfMonth", dayOfMonth);
        fragment.setArguments(args);
        return fragment;
    }

    public void setOnWeightEnteredListener(OnWeightEnteredListener listener) {
        mWeightEnteredListener = listener;
    }

    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = LayoutInflater.from(getActivity());
        final View view = inflater.inflate(R.layout.dialog_input_box, null);

        final EditText weightEditText = view.findViewById(R.id.weight_edit_text);
        weightEditText.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(view);
        builder.setTitle("Enter weight for " + getArguments().getInt("year") + "-" + getArguments().getInt("month") + "-" + getArguments().getInt("dayOfMonth") + ":");
        builder.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                String weightString = weightEditText.getText().toString();
                double weight = Double.parseDouble(weightString);
                int year = getArguments().getInt("year");
                int month = getArguments().getInt("month");
                int dayOfMonth = getArguments().getInt("dayOfMonth");
                mWeightEnteredListener.onWeightEntered(weight, year, month, dayOfMonth);
            }
        });
        builder.setNegativeButton("Cancel", null);
        return builder.create();
    }
}
