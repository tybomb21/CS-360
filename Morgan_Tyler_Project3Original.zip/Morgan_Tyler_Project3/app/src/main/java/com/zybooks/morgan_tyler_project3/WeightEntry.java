package com.zybooks.morgan_tyler_project3;
import java.util.Date;

public class WeightEntry {
    private long dateMillis;
    private double weight;

    public WeightEntry(long dateMillis, double weight) {
        this.dateMillis = dateMillis;
        this.weight = weight;
    }

    public long getDateMillis() {
        return dateMillis;
    }

    public double getWeight() {
        return weight;
    }
}
