package com.zybooks.morgan_tyler_project3;

public interface CalendarAdapter {
}
