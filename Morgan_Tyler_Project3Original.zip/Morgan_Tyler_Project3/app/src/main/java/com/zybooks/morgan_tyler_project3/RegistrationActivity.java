package com.zybooks.morgan_tyler_project3;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;
import android.database.sqlite.SQLiteDatabase;
import android.content.ContentValues;

import com.zybooks.morgan_tyler_project2.R;


public class RegistrationActivity extends AppCompatActivity {
    private EditText mUsernameEditText;
    private EditText mPasswordEditText;

    private SQLiteDatabase mDatabase;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);

        mUsernameEditText = findViewById(R.id.username_edittext);
        mPasswordEditText = findViewById(R.id.password_edittext);

        // Get the login credentials passed from MainActivity
        Intent intent = getIntent();
        String username = intent.getStringExtra("username");
        String password = intent.getStringExtra("password");

        mUsernameEditText.setText(username);
        mPasswordEditText.setText(password);

        // Create or open the database
        mDatabase = new LoginDatabaseHelper(this).getWritableDatabase();
    }

    public void onRegisterClick(View view) {
        String username = mUsernameEditText.getText().toString();
        String password = mPasswordEditText.getText().toString();

        // Insert the new login credentials into the database
        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password", password);

        mDatabase.insert("login", null, values);

        // Successful registration
        Toast.makeText(this, "Registration successful!", Toast.LENGTH_SHORT).show();
        finish();
    }
}
